//dorsa dorri
//40223032
#include <stdio.h>
#include <math.h>

void solver(int a, int b, int c, float *root1, float *root2);
int main()
{
    int a, b, c;
    float delta, root1, root2;
    printf("enter 3 integer quadratic ceofficients: \n");
    scanf("%d %d %d", &a, &b, &c);
    delta = (float)b*b-4*a*c;
    if (a==0 && b==0)
    {
        printf("incorrect values!");
    }
    else if (a==0)
    {
        printf("the equation has one real root: \n");
        printf("%f", (float)-c/b);
    }
    else if (delta<0)
    {
        printf("the equation has no real solution");
    }
    else if (delta==0)
    {
        printf("the equation has one real root: \n");
        printf("%f", (float)-0.5*b/a);
    }
    else
    {
        solver(a, b, c, &root1, &root2);
        printf("the equation has 2 real roots: \n");
        printf("%f \n%f \n",root1 ,root2);
    }
    return 0;
}
void solver(int a, int b, int c, float *root1, float *root2)
{
    *root1 = (float) -0.5*(b+sqrt(b*b-4*a*c))/a;
    *root2 = (float) -0.5*(b-sqrt(b*b-4*a*c))/a;
}