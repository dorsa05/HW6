//dorsa dorri
//40223032

#include <stdio.h>
#include <math.h>

int a, b, c;
float delta, sum;
float solver(int x, int y, int z);
int main()
{
    printf("enter 3 integer quadratic ceofficients: \n");
    scanf("%d %d %d", &a, &b, &c);
    delta = (float)b*b-4*a*c;
    sum = (float)-b/a;
    if (a==0 && b==0)
    {
        printf("incorrect values!");
    }
    else if (a==0)
    {
        printf("the equation has one real root: \n");
        printf("%f", (float)-c/b);
    }
    else if (delta<0)
    {
        printf("the equation has no real solution");
    }
    else if (delta==0)
    {
        printf("the equation has one real root: \n");
        printf("%f", (float)-0.5*b/a);
    }
    else
    {
        printf("the equation has 2 real roots: \n");
        printf("%f \n", solver(a, b, c));
        //calculation the other root using sum - one root
        printf("%f", (float)sum-solver(a, b, c));
    }
    return 0;
}
float solver(int x, int y, int z)
{
    //finding one root using quadratic formula
    return (-0.5*(y+sqrt(y*y-4*x*z)))/x;
}